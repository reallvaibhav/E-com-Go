package config

const (
	InventoryServiceURL = "http://inventory-service:8080" // Docker
	// OR "http://localhost:8080" for local testing
)
